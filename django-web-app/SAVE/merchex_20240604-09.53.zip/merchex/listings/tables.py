import django_tables2 as tables
from .models import Band
from django.urls import reverse

class BandTable(tables.Table):
    name = tables.LinkColumn('band_detail', args=[tables.A('pk')], verbose_name='Detail')
    detail = tables.LinkColumn('band_detail', text='View Details', args=[tables.A('pk')], verbose_name='Detail')

    class Meta:
        model = Band
        template_name = "django_tables2/bootstrap.html"
        fields = ('name', 'genre', 'year_formed', 'biography', 'active', 'official_homepage')